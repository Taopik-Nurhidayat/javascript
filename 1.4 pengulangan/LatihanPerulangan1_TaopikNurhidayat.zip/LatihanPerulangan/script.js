//tugas ke 1

// for (let x = 1; x <= 50; x++) {
//   if (x % 2 === 1) {
//     console.log(x + " adalah bilangan ganjil");
//   } else {
//     console.log(x + " adalah bilangan genap");
//   }
// }

//tugas ke 2

//mengunakan for

// for (let x = 1; x <= 100; x++) {
//   if (x % 3 === 0) {
//     console.log(x +" Adalah bilangan yang habis di bagi 3");
//   } else {
//     console.log(x +" ");
//   }
// }

//menggunakan while
// let i = 1;
// while (i <= 100) {
//   if (i % 3 === 0) {
//     console.log(i + " Adalah bilangan yang habis di bagi 3");
//   } else {
//     console.log(i + " ");
//   }
//   i++;
// }

//tugas 3

let i = 50;
while (i <= 150) {
  if (i % 4 === 0) {
    console.log(i + " Adalah bilangan yang habis di bagi 4");
  } else {
    console.log(i + " ");
  }
  i++;
}
